using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Rat
    {
        public string Name { get; set; }
        public int Number { get; set; }
        public bool IsRadioactive { get; set; }
    }
}