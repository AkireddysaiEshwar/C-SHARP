﻿// // Type safe Function
// Action loggerAction = () => 
// {
//     System.Console.WriteLine("This is simple");
// };

// Func<int, int> loggerFunc = (int x) => 
// {
//     return x + 2;
// }

// var list = Enumerable.Range(1, 10).Select(i => i * 3).ToList();

// var callcall = (loggerAction func) =>
// {
//     func();
// }

// callcall(loggerAction);

// public delegate int SuperCustom(int x);

// # Dictonery
